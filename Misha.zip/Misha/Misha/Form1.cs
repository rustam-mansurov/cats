namespace Misha
{
    public partial class Form1 : Form
    {
        int i = 0;
        public Form1()
        {
            InitializeComponent();

        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {

        }

        private void richTextBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.S)
            {
                timer1.Enabled = true;
            }

            if (e.KeyCode == Keys.F)
            {
                timer1.Enabled = false;
            }

            if (e.KeyCode == Keys.C)
            {
                i = 0;
                timer1.Enabled = false;
                richTextBox1.Text = 0.ToString();
                richTextBox2.Text = 0.ToString();
                richTextBox3.Text = 0.ToString();
                richTextBox4.Text = 0.ToString();
                richTextBox5.Text = 0.ToString();
            }

            if (e.KeyCode == Keys.Escape)
            {
                System.Windows.Forms.Application.ExitThread();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            richTextBox1.ReadOnly = true;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            i++;
            if (i % 10 == 0)
            {
                richTextBox4.Text = ((i % 100)/10).ToString();
            }
            if (i % 100 == 0)
            {
                richTextBox3.Text = ((i % 1000) / 100).ToString();
            }

            if (i % 1000 == 0)
            {
                richTextBox2.Text = ((i % 10000) / 1000).ToString();
            }

            if (i % 10000 == 0)
            {
                richTextBox1.Text = ((i % 100000) / 10000).ToString();
            }
            richTextBox5.Text = (i % 10).ToString();
        }
    }
}